import sqlite3
from datetime import date
from flask import Flask, request, jsonify
from flask_cors import CORS
from models import Categoria, Cliente, Livro, Pedido, ItemPedido
from dao import inicializar_banco, CategoriaDAO, ClienteDAO, LivroDAO, PedidoDAO

app = Flask(__name__)
CORS(app)

inicializar_banco()

categoria_dao = CategoriaDAO()
cliente_dao = ClienteDAO()
livro_dao = LivroDAO()
pedido_dao = PedidoDAO()


@app.route("/api/categorias", methods=["GET"])
def listar_categorias():
    return jsonify([c.to_dict() for c in categoria_dao.buscar_todos()])


@app.route("/api/categorias", methods=["POST"])
def criar_categoria():
    dados = request.json
    id_gerado = categoria_dao.inserir(Categoria(None, dados["nome"]))
    return jsonify({"id_categoria": id_gerado, "mensagem": "Categoria cadastrada!"}), 201


@app.route("/api/categorias/<int:id_categoria>", methods=["PUT"])
def atualizar_categoria(id_categoria):
    categoria_dao.atualizar(Categoria(id_categoria, request.json["nome"]))
    return jsonify({"mensagem": "Categoria atualizada!"})


@app.route("/api/categorias/<int:id_categoria>", methods=["DELETE"])
def remover_categoria(id_categoria):
    try:
        categoria_dao.remover(id_categoria)
        return jsonify({"mensagem": "Categoria removida!"})
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Não é possível excluir: existem livros vinculados."}), 400


@app.route("/api/clientes", methods=["GET"])
def listar_clientes():
    return jsonify([c.to_dict() for c in cliente_dao.buscar_todos()])


@app.route("/api/clientes", methods=["POST"])
def criar_cliente():
    dados = request.json
    try:
        id_gerado = cliente_dao.inserir(Cliente(None, dados["nome"], dados["email"], dados.get("telefone", "")))
        return jsonify({"id_cliente": id_gerado, "mensagem": "Cliente cadastrado!"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Este e-mail já está cadastrado para outro cliente."}), 400


@app.route("/api/clientes/<int:id_cliente>", methods=["PUT"])
def atualizar_cliente(id_cliente):
    dados = request.json
    try:
        cliente_dao.atualizar(Cliente(id_cliente, dados["nome"], dados["email"], dados.get("telefone", "")))
        return jsonify({"mensagem": "Cliente atualizado!"})
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Este e-mail já pertence a outro cliente."}), 400


@app.route("/api/clientes/<int:id_cliente>", methods=["DELETE"])
def remover_cliente(id_cliente):
    try:
        cliente_dao.remover(id_cliente)
        return jsonify({"mensagem": "Cliente removido!"})
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Não é possível excluir: cliente possui pedidos."}), 400


@app.route("/api/livros", methods=["GET"])
def listar_livros():
    return jsonify([l.to_dict() for l in livro_dao.buscar_todos()])


@app.route("/api/livros", methods=["POST"])
def criar_livro():
    dados = request.json
    id_gerado = livro_dao.inserir(Livro(None, dados["titulo"], dados["autor"], dados["preco"], dados["ano_publicacao"], dados["id_categoria"]))
    return jsonify({"id_livro": id_gerado, "mensagem": "Livro adicionado!"}), 201


@app.route("/api/livros/<int:id_livro>", methods=["PUT"])
def atualizar_livro(id_livro):
    dados = request.json
    livro_dao.atualizar(Livro(id_livro, dados["titulo"], dados["autor"], dados["preco"], dados["ano_publicacao"], dados["id_categoria"]))
    return jsonify({"mensagem": "Livro atualizado!"})


@app.route("/api/livros/<int:id_livro>", methods=["DELETE"])
def remover_livro(id_livro):
    try:
        livro_dao.remover(id_livro)
        return jsonify({"mensagem": "Livro removido!"})
    except sqlite3.IntegrityError:
        return jsonify({"erro": "Não é possível excluir: livro vinculado a pedido."}), 400


@app.route("/api/pedidos", methods=["GET"])
def listar_pedidos():
    return jsonify([p.to_dict() for p in pedido_dao.buscar_todos()])


@app.route("/api/pedidos", methods=["POST"])
def criar_pedido():
    dados = request.json
    itens_raw = dados.get("itens", [])
    if not itens_raw:
        return jsonify({"erro": "Adicione pelo menos um livro ao pedido."}), 400
    itens_obj = [ItemPedido(None, i["id_livro"], i["quantidade"], i["preco_unitario"]) for i in itens_raw]
    valor_total = sum(i.quantidade * i.preco_unitario for i in itens_obj)
    novo = Pedido(None, dados.get("data_pedido") or date.today().isoformat(), dados.get("status", "Pendente"), valor_total, dados["id_cliente"], itens=itens_obj)
    id_gerado = pedido_dao.inserir(novo)
    return jsonify({"id_pedido": id_gerado, "mensagem": "Pedido registrado!"}), 201


@app.route("/api/pedidos/<int:id_pedido>", methods=["PUT"])
def atualizar_pedido(id_pedido):
    pedido_dao.atualizar_status(id_pedido, request.json["status"])
    return jsonify({"mensagem": "Status atualizado!"})


@app.route("/api/pedidos/<int:id_pedido>", methods=["DELETE"])
def remover_pedido(id_pedido):
    pedido_dao.remover(id_pedido)
    return jsonify({"mensagem": "Pedido excluído!"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
